package com.ctp.arquilliandemo.ex1.domain;

/**
 * 
 * @author Bartosz Majsak
 *
 */
public enum TransactionType {

    BUY, 
    SELL;

}
